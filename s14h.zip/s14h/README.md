# Primera opción: botones

- botones asociados a funciones

## Apuntes

- escenas > funciones
  - arbol de decisiones (botones, sliders) y secuencia
- contador, tecla
- usuarix

## escenas

- Escena1: color, botón, function
